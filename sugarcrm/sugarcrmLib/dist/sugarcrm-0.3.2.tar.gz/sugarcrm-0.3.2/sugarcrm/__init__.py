from sugarcrm import *
from sugarmodule import *
__version__ = "0.3.3"

# This is supposed to help importing, does nothing as far as I can tell
__ALL__ = ['sugarcrm']

